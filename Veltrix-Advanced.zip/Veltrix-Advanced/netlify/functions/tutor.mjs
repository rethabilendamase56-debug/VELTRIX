// Optional server-side AI tutor endpoint for Netlify.
// Set OPENAI_API_KEY in Netlify site environment variables to enable it.
// Never place a secret API key in app.js or any browser-side file.
export default async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  if (!process.env.OPENAI_API_KEY) {
    return Response.json({ error: "AI tutor is not configured yet. Add OPENAI_API_KEY in Netlify environment variables." }, { status: 503 });
  }
  try {
    const { message, language = "isiZulu" } = await req.json();
    if (!message || typeof message !== "string" || message.length > 1500) {
      return Response.json({ error: "Please send a message of up to 1,500 characters." }, { status: 400 });
    }
    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: { "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "gpt-4.1-mini",
        instructions: `You are Veltrix, a friendly, accurate language-learning tutor. Help the learner study ${language}. Explain simply, give short examples, distinguish dialect or regional variation when relevant, and never pretend uncertain translations are certain. Encourage respectful communication.`,
        input: message,
        max_output_tokens: 350
      })
    });
    const data = await response.json();
    if (!response.ok) return Response.json({ error: "The AI service could not complete that request." }, { status: 502 });
    const answer = data.output?.flatMap(x => x.content || []).find(x => x.type === "output_text")?.text || "I couldn't create a reply just now.";
    return Response.json({ reply: answer });
  } catch {
    return Response.json({ error: "Something went wrong. Please try again." }, { status: 500 });
  }
};
