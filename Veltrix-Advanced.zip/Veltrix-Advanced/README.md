# Veltrix Advanced — deploy-ready starter

**Tagline:** The world speaks. We connect.

This is a mobile-friendly, static-first Veltrix MVP designed so it can be deployed by uploading this folder to Netlify. It includes:

- Overview dashboard and learner profile
- Starter Academy lessons in isiZulu, isiXhosa and English
- Lesson knowledge checks and local XP/progress tracking
- AI Tutor preview with guided starter responses
- Starter phrase translator
- Speak page using the browser's speech synthesis where supported
- Culture learning cards and learner insights
- Optional Netlify serverless AI tutor endpoint

## Deploy from an Android tablet

1. Download and extract `Veltrix-Advanced.zip` using your tablet's Files app.
2. Open Chrome and go to https://app.netlify.com/drop
3. Sign in or create a Netlify account.
4. Upload the **extracted `Veltrix-Advanced` folder** (or drag the folder into the upload area if your browser supports it). If the browser only accepts a ZIP, use Netlify's current deploy instructions for ZIP upload.
5. Wait for Netlify to publish. Open the generated `.netlify.app` address.

If the mobile browser cannot select a folder, open Netlify in Chrome's Desktop site mode or use a file manager that can select the extracted folder. You do not need to install a code editor.

## Important: what is and isn't live

The website itself works as a front-end demo. The learner profile and progress are stored in that browser's local storage on that device. This is **not secure account authentication**, and progress will not sync between devices or users.

The Tutor page has guided demo responses. An optional Netlify Function is included for a real AI tutor connection, but it is not active until you configure a private API key. Do not paste a secret key into `app.js`.

### Enable the optional AI tutor endpoint

1. Deploy the project to Netlify.
2. In Netlify, open **Site configuration → Environment variables**.
3. Add `OPENAI_API_KEY` with an API key from an account you are authorised to use.
4. Redeploy the site.
5. The function is available at `/.netlify/functions/tutor`.

The current browser UI uses its local guided tutor preview; connecting the endpoint to the chat UI is a next development step.

## Before a public launch

For a real international service, add Supabase (or another managed backend) for secure authentication, database-backed progress, privacy controls, rate limiting and user deletion. Have fluent isiZulu and isiXhosa speakers review all learning content. The included dictionary is intentionally small and should not be treated as a professional translation service.

## Project structure

- `index.html` — app shell
- `styles.css` — responsive brand styling
- `app.js` — interactive front-end
- `netlify.toml` — Netlify publishing configuration
- `netlify/functions/tutor.mjs` — optional server-side AI tutor endpoint
